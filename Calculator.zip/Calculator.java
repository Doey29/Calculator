/**
  * @author Neil Oscar M. Hawan 
  * ITCC11 - A 2
  * Oct. 28,2020
  */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Calculator extends JFrame {
	private JFrame mainFrame;
	private JTextField text;
	private JPanel mainPanel,btnPanel;
	private GridLayout grid;
	private BorderLayout size;

	private JButton One,Two,Three,Four,Five,Six,Seven,Eight,Nine,Zero,Doublezero,Ans,Blank1,Blank2;
	private JButton Equals,Add,Subtract,Divide,Multiply,Clear,Dot,Backspace;
	private ActionListener btnActionListener,plusActionListener,subtractActionListener,divideActionListener,multiplyActionListener,clearActionListener,backspaceActionListener,equalsActionListener,ansActionListener;
	double n1=0, n2=0, ans=0;
	char operator;

public Calculator() {
		mainFrame = new JFrame ("Calculator");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		size = new BorderLayout();
		grid = new GridLayout(5,4);
		text = new JTextField(30);
		text.setHorizontalAlignment(JTextField.RIGHT);
		text.setBounds(30, 20, 200, 30);
		mainPanel = new JPanel (size);
		btnPanel = new JPanel(grid);

		btnActionListener = new MyActionListener();
		plusActionListener = new AddActionListener();
		subtractActionListener = new SubtractActionListener();
		divideActionListener = new DivideActionListener();
		multiplyActionListener = new MultiplyActionListener();
		clearActionListener = new ClearActionListener();
		backspaceActionListener = new BackspaceActionListener();
		equalsActionListener = new EqualsActionListener();
		ansActionListener = new AnsActionListener();
		
		One = new JButton("1");
		One.addActionListener(btnActionListener);
		Two = new JButton("2");
		Two.addActionListener(btnActionListener);
		Three = new JButton("3");
		Three.addActionListener(btnActionListener);
		Four = new JButton("4");
		Four.addActionListener(btnActionListener);
		Five = new JButton("5");
		Five.addActionListener(btnActionListener);
		Six = new JButton("6");
		Six.addActionListener(btnActionListener);
		Seven = new JButton("7");
		Seven.addActionListener(btnActionListener);
		Eight = new JButton("8");
		Eight.addActionListener(btnActionListener);
		Nine = new JButton("9");
		Nine.addActionListener(btnActionListener);
		Zero = new JButton("0");
		Zero.addActionListener(btnActionListener);
		Doublezero = new JButton("00");
		Doublezero.addActionListener(btnActionListener);
		Clear = new JButton ("C");
		Clear.addActionListener(clearActionListener);
		Backspace = new JButton ("<=");
		Backspace.addActionListener(backspaceActionListener);
		Add = new JButton ("+");
		Add.addActionListener(plusActionListener);
		Subtract = new JButton ("-");
		Subtract.addActionListener(subtractActionListener);
		Divide = new JButton ("/");
		Divide.addActionListener(divideActionListener);
		Multiply = new JButton ("*");
		Multiply.addActionListener(multiplyActionListener);
		Dot = new JButton (".");
		Dot.addActionListener(btnActionListener);
		Equals = new JButton ("=");
		Equals.addActionListener(equalsActionListener);
		Blank1 = new JButton ("");
		Blank2 = new JButton ("");
		Ans = new JButton ("Ans");
		Ans.addActionListener(ansActionListener);

		btnPanel.add(Seven);
		btnPanel.add(Eight);
		btnPanel.add(Nine);
		btnPanel.add(Add);
		btnPanel.add(Multiply);
		btnPanel.add(Four);
		btnPanel.add(Five);
		btnPanel.add(Six);
		btnPanel.add(Subtract);
		btnPanel.add(One);
		btnPanel.add(Two);
		btnPanel.add(Three);
		btnPanel.add(Add);
		btnPanel.add(Dot);
		btnPanel.add(Zero);
		btnPanel.add(Doublezero);
		btnPanel.add(Divide);
		btnPanel.add(Ans);
		btnPanel.add(Clear);
		btnPanel.add(Backspace);
		btnPanel.add(Equals);

		mainPanel.add(text, BorderLayout.PAGE_START);
		mainPanel.add(btnPanel, BorderLayout.CENTER);
		this.add(mainPanel);
		this.pack();
		this.setResizable(false);
		this.setVisible(true);

}
	class MyActionListener implements ActionListener{
	public void actionPerformed(ActionEvent action) {

	if(action.getActionCommand()== "C"){
		text.setText("");
	}
	else{
		String temp = text.getText();
		temp = temp + action.getActionCommand();
		text.setText(temp);
		
			}
		}
	}
	class EqualsActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		n2 = Double.parseDouble(text.getText());
		switch(operator) {
		case'+': 
			ans= n1 + n2;
			break;
		case'-':
			ans= n1 - n2;
			break;
		case'*':
			ans= n1*n2;
			break;
		case'/':
		try{
			ans= (int) n1/ (int) n2;
			break;
		} catch (ArithmeticException ae){
			System.out.println("Cannot divide by 0");
		}
		case'>':
			ans = ans;
			break;
	}
	n1=ans;
	text.setText(""+ans);

		}
	}
	class AddActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		try{ 
		n1 = Double.parseDouble(text.getText());
		operator = '+';
		text.setText("");
		} catch (NumberFormatException nfe) {
			text.setText("Please input a number (press clear)");
			System.out.println("Input a number");
		
		}
		}
	}
	class SubtractActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		try {
		n1 = Double.parseDouble(text.getText());
		operator = '-';
		text.setText("");
		} catch (NumberFormatException nfe) {
			text.setText("Please input a number (press clear)");
			System.out.println("Input a number");
		
		}
		}
	}
	class DivideActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		try {
			
		n1 = Double.parseDouble(text.getText());
		operator = '/';	
		text.setText("");
		} catch (NumberFormatException nfe) {
			text.setText("Please input a number (press clear)");
			System.out.println("Input a number");
		
		}
		}
	}
	class MultiplyActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		try {
		n1 = Double.parseDouble(text.getText());
		operator = '*';	
		text.setText("");
		} catch (NumberFormatException nfe) {
			text.setText("Please input a number (press clear)");
			System.out.println("Input a number");
		
		}
		}
	}

	class BackspaceActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		String display = text.getText();
		text.setText("");

		for (int i=0; i<display.length()-1; i++){
			text.setText(text.getText() + display.charAt(i));
			}

		}
	}
	class ClearActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		
		text.setText("");
		
		}
	}
	class AnsActionListener implements ActionListener{
		public void actionPerformed(ActionEvent action){
		text.setText(String.valueOf(ans));
		operator = '>';
		}
	}
	
	
}
