/**
  * @author Neil Oscar M. Hawan 
  * ITCC11 - A 2
  * Oct. 28, 2020
  */

class Main{

	public static void main (String args[]) {
	Calculator calc = new Calculator();
}
}