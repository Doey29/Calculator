/**
  * @author Neil Oscar M. Hawan 
  * ITCC11 - A 2
  * Oct. 28, 2020
  */
  
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

  class Converter extends JFrame {
		public JFrame frame;
		public SpringLayout layout;
		public JTextField amtrate, amtconvert, output;
		public JLabel rate, convert, result;
		public JPanel main;
		public GridLayout grid;
		public double x = 0, y = 0, ans = 0;


  public Converter (){

		frame = new JFrame("Converter");
		frame.setSize(300, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		grid = new GridLayout(3,0);
		main = new JPanel (grid); 
		
		
//creating textfield and label
		amtrate = new JTextField(20);
		amtrate.getDocument().addDocumentListener(new MyDocumentListener());
		output = new JTextField(20);	
		amtconvert = new JTextField(20);
		amtconvert.getDocument().addDocumentListener(new MyDocumentListener());
		rate = new JLabel("Current Rate:       \n" );
		convert = new JLabel("Amount: \n");
		result = new JLabel("Converted Amount:\n");		
//adding textfield and label to main
		main.add(rate);
		main.add(amtrate);
		main.add(convert);
		main.add(amtconvert);
		main.add(result);
		main.add(output);

		
		frame.add(main);
		frame.setVisible(true);
		frame.pack();
		frame.setResizable(false);
  }
 public class MyDocumentListener implements DocumentListener{
	  public void insertUpdate (DocumentEvent e) {
		  double ans = 0;
		  x = Double.parseDouble(amtconvert.getText());
		  y = Double.parseDouble(amtrate.getText());
		  ans = x*y;
		 // convert(Double.parseDouble(amtrate.getText()), Double.parseDouble(amtconvert.getText()));
		  output.setText(""+ans);
	  } 
	  public void removeUpdate (DocumentEvent e) {
		  double ans = 0;
		  x = Double.parseDouble(amtconvert.getText());
		  y = Double.parseDouble(amtrate.getText());
		  ans = x*y;
		  output.setText(""+ans);
	  } 
	  public void changedUpdate (DocumentEvent e) {
		  double ans = 0;
		  x = Double.parseDouble(amtconvert.getText());
		  y = Double.parseDouble(amtrate.getText());
		  ans = x*y;
		  output.setText(""+ans);
	  } 
	  
 }
 }
