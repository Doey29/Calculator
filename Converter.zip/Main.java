/**
  * @author Neil Oscar M. Hawan 
  * ITCC11 - A 2
  * Oct. 20,2020
  */
  
  class Main {
	  
	public static void main (String args[]) {
	Converter conv = new Converter();
	
	}
	}
	